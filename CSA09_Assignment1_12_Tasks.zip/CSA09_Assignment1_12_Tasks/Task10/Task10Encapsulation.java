class EncapsulatedSlot {
    private final int floor;
    private final int slotNumber;
    private String registrationNo;

    EncapsulatedSlot(int floor, int slotNumber) {
        if (floor < 0 || slotNumber < 0)
            throw new IllegalArgumentException("Floor and slot must be non-negative");
        this.floor = floor;
        this.slotNumber = slotNumber;
    }
    public int getFloor() { return floor; }
    public int getSlotNumber() { return slotNumber; }
    public String getRegistrationNo() { return registrationNo; }
    public boolean isFree() { return registrationNo == null; }

    public void park(String regNo) {
        if (regNo == null || regNo.isBlank())
            throw new IllegalArgumentException("Registration number required");
        if (!isFree()) throw new IllegalStateException("Slot already occupied");
        registrationNo = regNo;
    }
    public void release() {
        if (isFree()) throw new IllegalStateException("Slot is already free");
        registrationNo = null;
    }
}
public class Task10Encapsulation {
    public static void main(String[] args) {
        EncapsulatedSlot slot = new EncapsulatedSlot(0, 5);
        slot.park("TN10XY1010");
        System.out.println("Floor " + slot.getFloor() + ", slot " +
                slot.getSlotNumber() + ", vehicle " + slot.getRegistrationNo());
        slot.release();
        System.out.println("Free: " + slot.isFree());
    }
}
