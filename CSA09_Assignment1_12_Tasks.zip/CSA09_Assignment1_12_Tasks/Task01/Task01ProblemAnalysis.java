// Task 01: Candidate objects and responsibilities (simple executable model)
import java.util.*;

class VehicleRecord {
    String registrationNo;
    String type;
    VehicleRecord(String registrationNo, String type) {
        this.registrationNo = registrationNo;
        this.type = type;
    }
}
class ParkingSlotRecord {
    int floor, slot;
    VehicleRecord vehicle;
    ParkingSlotRecord(int floor, int slot) {
        this.floor = floor; this.slot = slot;
    }
    boolean isFree() { return vehicle == null; }
}
class ParkingTicketRecord {
    final int ticketNo;
    final VehicleRecord vehicle;
    final long entryTime;
    ParkingTicketRecord(int ticketNo, VehicleRecord vehicle) {
        this.ticketNo = ticketNo;
        this.vehicle = vehicle;
        this.entryTime = System.currentTimeMillis();
    }
}
public class Task01ProblemAnalysis {
    public static void main(String[] args) {
        VehicleRecord v = new VehicleRecord("TN01AB1234", "Car");
        ParkingSlotRecord s = new ParkingSlotRecord(0, 1);
        s.vehicle = v;
        ParkingTicketRecord t = new ParkingTicketRecord(1, v);
        System.out.println("Vehicle: " + v.registrationNo + " (" + v.type + ")");
        System.out.println("Slot: floor " + s.floor + ", slot " + s.slot);
        System.out.println("Ticket: " + t.ticketNo + ", entry recorded: " + (t.entryTime > 0));
    }
}
