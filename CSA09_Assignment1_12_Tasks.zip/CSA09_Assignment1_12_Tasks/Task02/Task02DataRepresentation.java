// Task 02: Data types and jagged-array representation
public class Task02DataRepresentation {
    public static void main(String[] args) {
        int floorNumber = 1;                 // whole-number index
        int slotNumber = 4;                  // whole-number index
        String registrationNo = "TN01AB1234";
        long entryTimeMillis = System.currentTimeMillis();
        double hourlyRate = 30.0;
        int[][] floorSlotCounts = {{20}, {15}, {25}}; // example counts per floor

        String[][] slots = new String[3][];
        slots[0] = new String[20];
        slots[1] = new String[15];
        slots[2] = new String[25];

        int minutes = 130;
        // Avoid integer truncation: ceiling(minutes / 60) using integer arithmetic.
        int billableHours = (minutes + 59) / 60;
        double fee = billableHours * hourlyRate;

        System.out.println("Floor/slot: " + floorNumber + "/" + slotNumber);
        System.out.println("Registration: " + registrationNo);
        System.out.println("Entry time: " + entryTimeMillis);
        System.out.println("Floors: " + slots.length + ", floor 1 slots: " + slots[0].length);
        System.out.println("Billable hours: " + billableHours + ", fee: Rs " + fee);
    }
}
