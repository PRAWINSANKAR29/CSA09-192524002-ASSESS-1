class FacilityTicket {
    private static int nextTicketNumber = 1000; // shared by all tickets
    private final int ticketNumber;
    private final String registrationNo;

    FacilityTicket(String registrationNo) {
        this.ticketNumber = ++nextTicketNumber;
        this.registrationNo = registrationNo;
    }
    static int getNextTicketNumber() { return nextTicketNumber + 1; }
    public String toString() { return ticketNumber + " - " + registrationNo; }
}
public class Task05StaticMembers {
    public static void main(String[] args) {
        FacilityTicket a = new FacilityTicket("TN01AA1111");
        FacilityTicket b = new FacilityTicket("TN02BB2222");
        System.out.println(a);
        System.out.println(b);
        System.out.println("Next ticket number: " + FacilityTicket.getNextTicketNumber());
    }
}
