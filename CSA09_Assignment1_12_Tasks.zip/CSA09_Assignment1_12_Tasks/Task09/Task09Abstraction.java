interface Payable {
    double paymentAmount();
    default void printReceipt() {
        System.out.println("Amount payable: Rs " + paymentAmount());
    }
}
abstract class AbstractParkingVehicle {
    private final String registrationNo;
    AbstractParkingVehicle(String registrationNo) {
        this.registrationNo = registrationNo;
    }
    public String getRegistrationNo() { return registrationNo; }
    public abstract double parkingFee(int hours);
}
class AbstractParkingCar extends AbstractParkingVehicle implements Payable {
    private final int parkedHours;
    AbstractParkingCar(String regNo, int parkedHours) {
        super(regNo);
        if (parkedHours < 0) throw new IllegalArgumentException("Invalid hours");
        this.parkedHours = parkedHours;
    }
    @Override public double parkingFee(int hours) { return hours * 30.0; }
    @Override public double paymentAmount() { return parkingFee(parkedHours); }
}
public class Task09Abstraction {
    public static void main(String[] args) {
        AbstractParkingCar car = new AbstractParkingCar("TN09AB9999", 3);
        System.out.println(car.getRegistrationNo());
        car.printReceipt();
    }
}
