abstract class BaseVehicle {
    protected final String regNo;
    BaseVehicle(String regNo) {
        this.regNo = regNo;
        System.out.println("Vehicle constructor");
    }
    abstract double ratePerHour();
}
class BaseCar extends BaseVehicle {
    BaseCar(String regNo) {
        super(regNo);
        System.out.println("Car constructor");
    }
    @Override double ratePerHour() { return 30.0; }
}
class BaseElectricCar extends BaseCar {
    BaseElectricCar(String regNo) {
        super(regNo);
        System.out.println("ElectricCar constructor");
    }
}
public class Task06Inheritance {
    public static void main(String[] args) {
        BaseElectricCar ev = new BaseElectricCar("TN03EV3333");
        System.out.println(ev.regNo + " rate Rs " + ev.ratePerHour() + "/hour");
    }
}
