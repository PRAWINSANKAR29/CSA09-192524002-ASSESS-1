# CSA09 Assignment 1 – Campus Smart-Parking System

This starter project contains one Java example folder for each of the 12 assignment tasks.

## Requirements
- JDK 17 or later (Task 8 uses pattern matching for `instanceof`).
- Compile and run each task from inside its folder.

## Compile and run
Example for Task 3:
```bash
cd Task03
javac ParkingFacility.java
java ParkingFacility
```

Repeat with the public class filename for each task:
- Task01: `Task01ProblemAnalysis`
- Task02: `Task02DataRepresentation`
- Task03: `ParkingFacility`
- Task04: `Task04Constructors`
- Task05: `Task05StaticMembers`
- Task06: `Task06Inheritance`
- Task07: `Task07Overriding`
- Task08: `FeeDemo`
- Task09: `Task09Abstraction`
- Task10: `Task10Encapsulation`
- Task11: `SmartParkingSystem`
- Task12: `UpdatedSmartParkingSystem`

## Important
These are starter implementations and examples aligned to the programming concepts in the assignment. Tasks 1 and 2 also require written analysis; Tasks 3 and 8 require the exact completed-code exercises; Task 11 requires your own expanded tests and evidence; Task 12 requires written impact analysis and defence. Add your own execution screenshots and complete the report. Verify all code and understand it before submission.
