import java.time.LocalTime;
import java.util.*;

interface DayPassHolder {
    boolean hasValidDayPass();
}
abstract class NewVehicle {
    final String regNo;
    NewVehicle(String regNo) {
        if (regNo == null || regNo.isBlank()) throw new IllegalArgumentException("Invalid registration");
        this.regNo = regNo;
    }
    abstract double calculateParkingFee(int minutes, LocalTime entry, LocalTime exit);
}
class NewCar extends NewVehicle {
    NewCar(String r) { super(r); }
    double calculateParkingFee(int minutes, LocalTime entry, LocalTime exit) {
        return ((minutes + 59) / 60) * 30.0;
    }
}
class EBike extends NewVehicle {
    EBike(String r) { super(r); }
    // Flat parking fee for an e-bike.
    double calculateParkingFee(int minutes, LocalTime entry, LocalTime exit) {
        return 20.0;
    }
}
class DeliveryVan extends NewVehicle {
    DeliveryVan(String r) { super(r); }
    // Double car rate during 9 AM–5 PM. This simple implementation applies
    // the double rate when the entry time falls in that window.
    double calculateParkingFee(int minutes, LocalTime entry, LocalTime exit) {
        double rate = (!entry.isBefore(LocalTime.of(9, 0)) &&
                       entry.isBefore(LocalTime.of(17, 0))) ? 60.0 : 30.0;
        return ((minutes + 59) / 60) * rate;
    }
}
class VisitorDayPass implements DayPassHolder {
    private final LocalTime validFrom, validUntil;
    VisitorDayPass(LocalTime from, LocalTime until) {
        validFrom = from; validUntil = until;
    }
    public boolean hasValidDayPass() {
        LocalTime now = LocalTime.now();
        return !now.isBefore(validFrom) && !now.isAfter(validUntil);
    }
}
public class UpdatedSmartParkingSystem {
    public static void main(String[] args) {
        NewVehicle[] vehicles = {
            new NewCar("TN20CA2020"),
            new EBike("TN21EB2121"),
            new DeliveryVan("TN22DV2222")
        };
        LocalTime entry = LocalTime.of(10, 0);
        LocalTime exit = LocalTime.of(11, 30);
        int minutes = 90;
        for (NewVehicle v : vehicles) {
            System.out.println(v.getClass().getSimpleName() + " " + v.regNo +
                " -> Rs " + v.calculateParkingFee(minutes, entry, exit));
        }

        VisitorDayPass pass = new VisitorDayPass(LocalTime.MIN, LocalTime.MAX);
        System.out.println("Visitor day pass valid now: " + pass.hasValidDayPass());

        // Jagged array supports different slot counts on each floor.
        String[][] floors = { new String[20], new String[15], new String[25],
                              new String[18], new String[30] };
        System.out.println("Facility floors: " + floors.length);
    }
}
