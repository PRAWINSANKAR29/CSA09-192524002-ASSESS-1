class ParkingTicket {
    private final int ticketId;
    private final String registrationNo;
    private final long entryTime;

    ParkingTicket() {
        this(0, "UNKNOWN", System.currentTimeMillis());
    }
    ParkingTicket(int ticketId, String registrationNo) {
        this(ticketId, registrationNo, System.currentTimeMillis());
    }
    ParkingTicket(int ticketId, String registrationNo, long entryTime) {
        if (ticketId < 0) throw new IllegalArgumentException("Ticket ID cannot be negative");
        if (registrationNo == null || registrationNo.isBlank())
            throw new IllegalArgumentException("Registration number is required");
        this.ticketId = ticketId;
        this.registrationNo = registrationNo;
        this.entryTime = entryTime;
    }
    ParkingTicket(ParkingTicket other) {
        this(other.ticketId, other.registrationNo, other.entryTime);
    }
    public String toString() {
        return "Ticket " + ticketId + " | " + registrationNo + " | " + entryTime;
    }
}
public class Task04Constructors {
    public static void main(String[] args) {
        ParkingTicket t1 = new ParkingTicket(101, "TN01AB1234");
        ParkingTicket t2 = new ParkingTicket(t1);
        System.out.println(t1);
        System.out.println(t2);
    }
}
