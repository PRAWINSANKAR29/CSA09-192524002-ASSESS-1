import java.util.Objects;

abstract class RatedVehicle {
    private final String regNo;
    RatedVehicle(String regNo) { this.regNo = regNo; }
    abstract double calculateFee(int minutes);
    public String getRegNo() { return regNo; }

    @Override public String toString() {
        return getClass().getSimpleName() + "[" + regNo + "]";
    }
    @Override public boolean equals(Object obj) {
        if (!(obj instanceof RatedVehicle)) return false;
        RatedVehicle other = (RatedVehicle) obj;
        return regNo.equals(other.regNo);
    }
    @Override public int hashCode() { return Objects.hash(regNo); }
}
class RatedBike extends RatedVehicle {
    RatedBike(String regNo) { super(regNo); }
    @Override public double calculateFee(int minutes) {
        return ((minutes + 59) / 60) * 10.0;
    }
}
class RatedCar extends RatedVehicle {
    RatedCar(String regNo) { super(regNo); }
    @Override public double calculateFee(int minutes) {
        return ((minutes + 59) / 60) * 30.0;
    }
}
public class Task07Overriding {
    public static void main(String[] args) {
        RatedVehicle bike = new RatedBike("TN01A1");
        RatedVehicle car = new RatedCar("TN02B2");
        System.out.println(bike + " fee Rs " + bike.calculateFee(130));
        System.out.println(car + " fee Rs " + car.calculateFee(130));
        System.out.println("Same registration? " +
                car.equals(new RatedCar("TN02B2")));
    }
}
