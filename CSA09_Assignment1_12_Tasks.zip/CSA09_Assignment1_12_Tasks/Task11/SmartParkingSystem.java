import java.util.*;

abstract class ParkedVehicle {
    private final String regNo;
    ParkedVehicle(String regNo) {
        if (regNo == null || regNo.isBlank()) throw new IllegalArgumentException("Invalid registration");
        this.regNo = regNo;
    }
    public String getRegNo() { return regNo; }
    abstract double hourlyRate();
}
class ParkedBike extends ParkedVehicle {
    ParkedBike(String r) { super(r); }
    double hourlyRate() { return 10; }
}
class ParkedCar extends ParkedVehicle {
    ParkedCar(String r) { super(r); }
    double hourlyRate() { return 30; }
}
class ParkedEV extends ParkedCar {
    ParkedEV(String r) { super(r); }
}
class Ticket {
    private static int nextId = 1000;
    final int id = ++nextId;
    final ParkedVehicle vehicle;
    final long entryMillis = System.currentTimeMillis();
    final int floor, slot;
    Ticket(ParkedVehicle v, int f, int s) {
        vehicle = v; floor = f; slot = s;
    }
    double feeForMinutes(int minutes) {
        if (minutes < 0) throw new IllegalArgumentException("Negative duration");
        return ((minutes + 59) / 60) * vehicle.hourlyRate();
    }
}
public class SmartParkingSystem {
    private final String[][] slots;
    private final Map<String, Ticket> active = new HashMap<>();

    SmartParkingSystem(int[] slotsPerFloor) {
        slots = new String[slotsPerFloor.length][];
        for (int i = 0; i < slotsPerFloor.length; i++) slots[i] = new String[slotsPerFloor[i]];
    }

    public Ticket enter(ParkedVehicle vehicle) {
        if (active.containsKey(vehicle.getRegNo()))
            throw new IllegalArgumentException("Duplicate registration");
        for (int f = 0; f < slots.length; f++) {
            for (int s = 0; s < slots[f].length; s++) {
                if (slots[f][s] == null) {
                    slots[f][s] = vehicle.getRegNo();
                    Ticket t = new Ticket(vehicle, f, s);
                    active.put(vehicle.getRegNo(), t);
                    return t;
                }
            }
        }
        return null;
    }

    public double exit(String regNo, int parkedMinutes) {
        Ticket t = active.remove(regNo);
        if (t == null) throw new IllegalArgumentException("No active ticket");
        slots[t.floor][t.slot] = null;
        return t.feeForMinutes(parkedMinutes);
    }

    public static void main(String[] args) {
        SmartParkingSystem p = new SmartParkingSystem(new int[]{2, 1});
        Ticket a = p.enter(new ParkedBike("TN11AA1111"));
        Ticket b = p.enter(new ParkedCar("TN12BB2222"));
        System.out.println("Ticket " + a.id + " allocated at " + a.floor + "," + a.slot);
        System.out.println("Ticket " + b.id + " allocated at " + b.floor + "," + b.slot);
        System.out.println("Bike exit fee for 60 minutes: Rs " + p.exit("TN11AA1111", 60));
        System.out.println("Car exit fee for 130 minutes: Rs " + p.exit("TN12BB2222", 130));
        System.out.println("Duplicate/invalid/zero-minute cases can be tested through enter() and exit().");
    }
}
